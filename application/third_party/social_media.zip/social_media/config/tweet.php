<?php

	$config['tweet_consumer_key'] = "ylgjqBRCq40EjY0HyyCkg";//xybLDKafhKTlyth5myoA";
	$config['tweet_consumer_secret'] = "2P8EmhCiNOvTw23ecVflkv9YzWWM6qlGosOw2o7TCI";//E8Rz8GsZZEZf9r6i6y5e5AgpvnhgW9oGpG9V6gegQ";
